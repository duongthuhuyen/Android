package com.example.beanikaa.common;

import com.example.beanikaa.data.Pojo.User;

public class Account {
   public static User account;
}
