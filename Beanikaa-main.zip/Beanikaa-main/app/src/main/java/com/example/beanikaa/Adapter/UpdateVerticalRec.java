package com.example.beanikaa.Adapter;

import com.example.beanikaa.Model.HomeItemModel;

import java.util.ArrayList;

public interface UpdateVerticalRec {
    public void callback(int position, ArrayList<HomeItemModel> list);
}
