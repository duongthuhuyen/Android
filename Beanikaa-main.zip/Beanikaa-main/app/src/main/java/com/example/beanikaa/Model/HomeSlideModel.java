package com.example.beanikaa.Model;

public class HomeSlideModel {
   private int image;

    public HomeSlideModel(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
