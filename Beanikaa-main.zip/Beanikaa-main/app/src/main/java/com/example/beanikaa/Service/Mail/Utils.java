package com.example.beanikaa.Service.Mail;

public class Utils {

    //This is your from email
    public static final String EMAIL = "duongthithuhuyen26122001@gmail.com";

    //This is your from email password
    public static final String PASSWORD = "pass";
}
